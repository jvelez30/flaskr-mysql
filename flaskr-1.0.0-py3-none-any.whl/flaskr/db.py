#!/usr/bin/env python3
#import sqlite3
import click
import sys
from flask import current_app, g
from flask.cli import with_appcontext
import mysql.connector
import logging, os

logging.basicConfig(filename='mydb.log', level=logging.INFO)

def get_env_vars():    
    database_host = os.environ['DATABASE_HOST']
    database_user = os.environ['DATABASE_USER']
    database_password = os.environ['DATABASE_PASSWORD']
    database_name = os.environ['DATABASE_NAME']
    return database_host, database_user, database_password, database_name

def get_db():
    if 'db' not in g:
        database_host, database_user, database_password, database_name = get_env_vars()
        g.db = mysql.connector.connect(
            user=database_user,
            password=database_password,
            database=database_name,
            host=database_host, # name of the mysql service as set in the docker-compose file
            auth_plugin='mysql_native_password'
        )
        g.db.cursor(dictionary=True)
    return g.db

def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()

def init_db():
    db = get_db()
    logging.info("Entre a Init Db")
    logging.info(vars(db))
    with current_app.open_resource('schema.sql') as f:
        db.cursor().execute('DROP TABLE IF EXISTS post;')
        db.cursor().execute('DROP TABLE IF EXISTS user;')
        db.cursor().execute('CREATE TABLE user (id INT NOT NULL AUTO_INCREMENT, username VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, PRIMARY KEY (id), CONSTRAINT UC_username UNIQUE (username));')
        db.cursor().execute('CREATE TABLE post (id INT NOT NULL AUTO_INCREMENT, author_id INT NOT NULL, created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,  title MEDIUMTEXT NOT NULL,  body LONGTEXT NOT NULL,  PRIMARY KEY (id),  FOREIGN KEY (author_id) REFERENCES user (id));')
        db.commit()

@click.command('init-db')
@with_appcontext
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')

def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)

